/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minha_agenda;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.effects.JFXDepthManager;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.swing.JOptionPane;
import minha_agenda.mysqlConnect;

/**
 * FXML Controller class
 *
 * @author Angola Developers
 */
    

public class Login_Controller implements Initializable {
        Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    
    @FXML
    private Button button;
    @FXML
    private AnchorPane cardPane;
    @FXML
     private JFXTextField txtNome;
    @FXML
     private JFXPasswordField txtSenha;
   
    /**
     * Initializes the controller class.
     */
        
        @FXML
        void login(ActionEvent event){
            String nome;
        nome = txtNome.getText();
        conn=mysqlConnect.ConnectDB();
        String sql="Select * from login where nome=? and senha=?";
 try{
          pst=(PreparedStatement) conn.prepareStatement(sql);
          pst.setString(1, txtNome.getText());
          pst.setString(2, txtSenha.getText());
          rs=pst.executeQuery();
 if(
         rs.next()){
          txtNome.setText("");
          txtSenha.setText("");
          
          JOptionPane.showMessageDialog(null, "Ola, Mundo");
          
//          Parent parent = FXMLLoader.load(getClass().getResource("MainView.fxml"));
//          ((Node) (event.getSource())).getScene().getWindow().hide();
//          Stage stage = new Stage();
//          Scene scene = new Scene(parent);
//          stage.setScene(scene);
//         stage.initStyle(StageStyle.UNDECORATED);
//          stage.setMaximized(true);
//          stage.show();
 }else{
                txtNome.setText("");
                 txtSenha.setText("");
                JOptionPane.showMessageDialog(null, "Nome ou Senha Errado, tente Novamente");
 }
 
 }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
 }
 
            //System.out.println("O teu nome "+ txtNome.getText()+" Esta certo");
        }
    
        @FXML
        void CloseLogin(ActionEvent event){
         Platform.exit();
        }
        
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        JFXDepthManager.setDepth(cardPane, 2);
    }    
    
}
